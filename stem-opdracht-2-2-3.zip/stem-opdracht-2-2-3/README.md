# STEM opdracht 2.2.3

A Pen created on CodePen.io. Original URL: [https://codepen.io/Felix-Morrhey/pen/KKEQVNM](https://codepen.io/Felix-Morrhey/pen/KKEQVNM).

